export const baseURL = 'http://localhost:8060';
export const reactBaseURL = 'http://localhost:3000';
