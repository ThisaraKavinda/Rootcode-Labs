# RootCode Labs technical assesment

# Starting backend

Navigate to the "backend" folder and open a terminal for that location. 
First execute "npm i" command to install the packages
By executing the command "npm start" you can start backend server for the port 8060.

# Starting frontend

Navigate to the "frontend" folder and open a seperate terminal there.
Execute "npm i" command to install the packages
By executing the same command "npm start" you can start the frontend server
